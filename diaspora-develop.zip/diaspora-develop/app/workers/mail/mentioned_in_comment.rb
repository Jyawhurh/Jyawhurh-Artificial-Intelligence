# frozen_string_literal: true

module Workers
  module Mail
    class MentionedInComment < NotifierBase
    end
  end
end
